package com.fis.bankapp.dao;

import com.fis.bankapp.model.Account; //importing 'Account' class from 'com.fis.bankapp.model' package
import com.fis.bankapp.exceptions.NotEnoughBalance; //importing 'NotEnoughbalance' exception class
import com.fis.bankapp.exceptions.AccountNotFound; //importing 'AccountNotFound' exception class

public interface AccountRepository {
	public abstract String addAccount(Account account);// abstract method to add an account

	public abstract String deleteAccount(long accNo) throws AccountNotFound;// abstract method to delete an account

	public abstract Account getAccount(long getAcc) throws AccountNotFound;// abstract to get an account

	public abstract void withdrawFromBalance(long getAcc, double withdrawAmount) throws NotEnoughBalance;// abstract
																											// method to
																											// withdraw
																											// from an
																											// account
																											// balance

	public abstract void depositIntoBalance(long getAcc, double depositAmount);// abstract method to deposit in to an
																				// account

}
