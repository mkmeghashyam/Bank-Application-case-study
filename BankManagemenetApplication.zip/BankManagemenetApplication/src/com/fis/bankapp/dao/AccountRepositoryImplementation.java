package com.fis.bankapp.dao;

import java.util.HashMap;

import com.fis.bankapp.model.Account;
import com.fis.bankapp.exceptions.AccountNotFound;
import com.fis.bankapp.exceptions.NotEnoughBalance;

public class AccountRepositoryImplementation implements AccountRepository {// inheriting the AccountRepository class

	HashMap<Long, Account> Accounts = new HashMap<Long, Account>();

	@Override
	public String addAccount(Account account) {// overriding the method addAccount

		Accounts.put(account.getaccNo(), account);

		return "Account Added Successfully!";
	}

	@Override
	public String deleteAccount(long accNo) throws AccountNotFound {// overriding the method deleteAccount
		if (Accounts.containsKey(accNo)) {
			Accounts.remove(accNo);
			return "Employee Deleted Successfully";
		} else {
			throw new AccountNotFound("Invalid Acc No");
		}
	}

	@Override
	public Account getAccount(long getAcc) throws AccountNotFound {// overriding the method getAccount

		if (Accounts.containsKey(getAcc)) {
			return Accounts.get(getAcc);
		} else {
			throw new AccountNotFound("Invalid Account Number");
		}
	}

	@Override
	public void withdrawFromBalance(long getAcc, double withdrawAmount) throws NotEnoughBalance {// overriding the
																									// method
																									// withdrawFromBalance

		if (Accounts.containsKey(getAcc) && (Accounts.get(getAcc).getbalance() - withdrawAmount) > -1) {
			Accounts.get(getAcc).setbalance(Accounts.get(getAcc).getbalance() - withdrawAmount);
		} else {
			throw new NotEnoughBalance("Not enough Balance");
		}
	}

	@Override
	public void depositIntoBalance(long getAcc, double depositAmount) {// overriding the method depositIntoBalance

		if (Accounts.containsKey(getAcc)) {
			Accounts.get(getAcc).setbalance(Accounts.get(getAcc).getbalance() + depositAmount);
		}
	}

}
