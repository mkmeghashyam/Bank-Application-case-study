package com.fis.bankapp.dao;

import java.util.ArrayList;

import com.fis.bankapp.model.Transaction;

public interface TransactionRepo {

	public abstract String addDeposit(long dpAccNo, Transaction transaction);

	public abstract String addWithdraw(long wdAccNo, Transaction transaction);

	public abstract String addTransactionNEFT(long transFromAcc, long neftAccNo, Transaction transaction);// abstract
																											// method to
																											// add a
																											// NEFT
																											// transaction.

	public abstract ArrayList<String> getTransForAccNo(Transaction transaction, long showTransAccNo);// abstract method
																										// to
																										// getTransForAccNo

}
