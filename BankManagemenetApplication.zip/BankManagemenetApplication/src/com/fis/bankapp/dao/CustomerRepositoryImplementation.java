package com.fis.bankapp.dao;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import com.fis.bankapp.model.Customer;
import com.fis.bankapp.exceptions.CustomerNotFound;

public class CustomerRepositoryImplementation implements CustomerRepository {

	HashMap<Integer, Customer> customers = new HashMap<Integer, Customer>();//creating the object using hashmap

	@Override
	public String addCustomer(Customer customer) {// overriding the method addCustomer
		customers.put(customer.getcustId(), customer);
		return "Customer Saved Successfully";
	}

	@Override
	public String updateCustomer(Customer customer) throws CustomerNotFound {/// overriding the method updateCustomer
		if (customers.containsKey(customer.getcustId())) {
			customers.put(customer.getcustId(), customer);
			return "Customer Updated Successfully";
		} else {
			throw new CustomerNotFound("Invalid Customer Id");
		}
	}

	@Override
	public String deleteCustomer(int custId) throws CustomerNotFound {// overriding the method deletecustomer
		if (customers.containsKey(custId)) {
			customers.remove(custId);
			return "Customer Deleted Successfully";
		} else {
			throw new CustomerNotFound("Invalid Customer Id");
		}
	}

	@Override
	public Customer getCustomer(int custId) throws CustomerNotFound {
		if (customers.containsKey(custId)) {
			return customers.get(custId);
		} else {
			throw new CustomerNotFound("Invalid Customer Id");
		}

	}

	@Override
	public Set<Customer> getAllCustomers() {//using key we will get the customer
		Set<Integer> set = customers.keySet();
		Set<Customer> cust = new HashSet<Customer>();
		Iterator<Integer> keys = set.iterator();
		while (keys.hasNext()) {
			int key = keys.next();
			cust.add(customers.get(key));
		}
		return cust;
	}

}
