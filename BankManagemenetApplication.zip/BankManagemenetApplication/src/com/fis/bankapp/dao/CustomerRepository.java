package com.fis.bankapp.dao;

import java.util.Set;

import com.fis.bankapp.model.Customer;
import com.fis.bankapp.exceptions.CustomerNotFound;

public interface CustomerRepository {
	public abstract String addCustomer(Customer customer);//abstract method to add customer 

	public abstract String updateCustomer(Customer customer) throws CustomerNotFound;//abstract method to update customer 

	public abstract String deleteCustomer(int custId) throws CustomerNotFound;//abstract method to delete customer

	public abstract Customer getCustomer(int custId) throws CustomerNotFound;//abstract method to get a customer

	public abstract Set<Customer> getAllCustomers();//abstract method to get all customers

}
