package com.fis.bankapp.main;

import java.util.Date;//importing the required classes from different packages
import java.util.Scanner;

import com.fis.bankapp.model.Customer;
import com.fis.bankapp.model.Account;
import com.fis.bankapp.model.Transaction;
import com.fis.bankapp.exceptions.CustomerNotFound;
import com.fis.bankapp.service.CusSer;
import com.fis.bankapp.service.CusSerImp;
import com.fis.bankapp.exceptions.AccountNotFound;
import com.fis.bankapp.service.AccSer;
import com.fis.bankapp.service.AccSerImp;

import com.fis.bankapp.service.TranSer;
import com.fis.bankapp.service.TranSerImp;
import com.fis.bankapp.exceptions.NotEnoughBalance;

public class BankManagementApp {

	public static void main(String[] args) {
		int custId = 10;
		String custName;
		String custDob;
		long mobile;
		String custMail;
		String custAddress;
		long accNo = 100;
		String accType;
		String branch;
		String ifsc;
		double balance = 0;
		int transId = 1000;
		long accNoFrom;
		long accNoTo;
		double amount;
		Date dateOfTrans;
		String transType;

		Customer customer = null; // Declaration of 'customer' as null reference
		CusSer service = new CusSerImp();

		Account account = null; // Declaration of 'Account' as null reference
		AccSer service2 = new AccSerImp();

		Transaction transaction = null; // Declaration of 'Transaction' as null reference
		TranSer service3 = new TranSerImp();

		Scanner scanner = new Scanner(System.in);
		while (true) {
			System.out.println("********Banking Services********");
			System.out.println("1.Customer Registration");
			System.out.println("2.Create User Account");
			System.out.println("3.Money Deposit");
			System.out.println("4.Money Withdraw");
			System.out.println("5.Delete customer Account");
			System.out.println("6.Show Customer Details");
			System.out.println("7.Show Account Details");
			System.out.println("8.Fund Transfer");
			System.out.println("9.Transactions");
			System.out.println("10.Exit Application");
			
			int option = scanner.nextInt(); // reading the user's choice

			switch (option) { // switch case to handle the menu options based on the user input
			case 1:// customer registration
				System.out.println("Enter Details To Register");
				System.out.println("Enter Your Name");
				custName = scanner.next();
				System.out.println("Enter Your Date of Birth");
				custDob = scanner.next();
				System.out.println("Enter Your Mobile Number");
				mobile = scanner.nextLong();
				System.out.println("Enter Your Mail ID");
				custMail = scanner.next();
				System.out.println("Enter Your Address");
				custAddress = scanner.next();
				custId = custId + 1;// increment of customer id
				customer = new Customer(custId, custName, custDob, mobile, custMail, accNo, custAddress);
				System.out.println(service.addCustomer(customer) + " with custId: " + custId);

				break;
			case 2:// user account creation
				System.out.println("Enter Details To Create Account");
				System.out.println("Enter Your Account Type");
				accType = scanner.next();
				System.out.println("Enter Your Branch");
				branch = scanner.next();
				System.out.println("Enter Your Branch IFSC Code");
				ifsc = scanner.next();
				accNo = accNo + 1;// increment of account number
				account = new Account(custId, accNo, accType, branch, ifsc, balance);
				System.out.println(service2.addAccount(account) + " with accNo: " + accNo);
				break;
			case 3:// money deposit
				System.out.println("DEPOSIT INTO ACCOUNT");
				System.out.println("Enter account number into which you wish to deposit: ");
				long dpAccNo = scanner.nextLong();
				try {
					System.out.println(service2.getAccount(dpAccNo));
					System.out.println("Enter amount you wish to deposit: ");
					double dpAmount = scanner.nextDouble();
					System.out.println("Old Balance : " + service2.getAccount(dpAccNo).getbalance());// displays the old
																										// balance of
																										// the
																										// user
					service2.depositIntoBalance(dpAccNo, dpAmount);
					System.out.println("New Balance : " + service2.getAccount(dpAccNo).getbalance());// displays the new
																										// balance of
																										// the user
				} catch (AccountNotFound anf) {
					System.out.println("Invalid Account Number...");
				}
				break;

			case 4:// money withdraw
				System.out.println("WITHDRAW FROM ACCOUNT");
				System.out.println("Enter account number from which you wish to withdraw: ");
				long wdAccNo = scanner.nextLong();
				try {
					System.out.println(service2.getAccount(wdAccNo));
					System.out.println("Enter amount you wish to withdraw: ");
					double wdAmount = scanner.nextDouble();
					if (wdAmount <= (service2.getAccount(wdAccNo).getbalance())) {
						System.out.println("Old Balance : " + service2.getAccount(wdAccNo).getbalance());
						service2.withdrawFromBalance(wdAccNo, wdAmount);
						System.out.println("New Balance : " + service2.getAccount(wdAccNo).getbalance());
					} else {
						throw new NotEnoughBalance("Not enough Balance");
					}
				} catch (AccountNotFound anf) {
					System.out.println("Invalid Account Number...");
				} catch (NotEnoughBalance neb) {
					System.out.println("Not enough Balance");
				}
				break;

			case 5:// to delete the customer account
				System.out.println("Delete Account");
				System.out.println("Enter Your Account Number");
				accNo = scanner.nextLong();
				try {
					System.out.println(service2.deleteAccount(accNo));
				} catch (AccountNotFound e) {
					System.out.println("Enter valid Account Number....");
				}
				break;
			case 6:// displaying the customers account details
				System.out.println("Enter Customer Details To Get");
				System.out.println("Enter Your Customer ID");
				custId = scanner.nextInt();
				try {
					System.out.println(service.getCustomer(custId));
				} catch (CustomerNotFound e) {
					System.out.println("Enter valid Customer Id....");
				}
				break;
			case 7:// displays the account details of the customer
				System.out.println("Enter Account Details To Get");
				System.out.println("Enter Your Account Number");
				accNo = scanner.nextInt();
				try {
					System.out.println(service2.getAccount(accNo));
				} catch (AccountNotFound e) {
					System.out.println("Enter valid Account Number....");
				}
				break;

			case 8:// fund transfer through NEFT,RTGS,IMPS
				System.out.println("FUND TRANSFER");
				System.out.println("Enter your account number to start transaction: ");
				long transFromAcc = scanner.nextLong();
				try {
					System.out.println(service2.getAccount(transFromAcc));
					System.out.println("Enter which service you wish to use:\n1. NEFT\n2. RTGS\n3. IMPS");
					int transServiceRequested = scanner.nextInt();
					switch (transServiceRequested) {
					case 1:
						System.out.println("NEFT selected...");
						System.out.println("Enter beneficiary account number: ");
						long neftAccNo = scanner.nextLong();
						try {
							service2.getAccount(neftAccNo);
						} catch (AccountNotFound anf) {
							System.out.println("Wrong Account Number of beneficiary... Transaction Cancelled...");
						}
						System.out.println("Enter Amount to transfer: ");
						double neftAmount = scanner.nextDouble();

						try {
							double transWithdrawAmount = neftAmount;
							if (transWithdrawAmount <= (service2.getAccount(transFromAcc).getbalance())) {
								System.out.println("Old Balance of " + transFromAcc + " is "
										+ service2.getAccount(transFromAcc).getbalance());
								service2.withdrawFromBalance(transFromAcc, transWithdrawAmount);
								System.out.println("New Balance of " + transFromAcc + " is "
										+ service2.getAccount(transFromAcc).getbalance());
							} else {
								throw new NotEnoughBalance("Not enough Balance");
							}
						} catch (NotEnoughBalance neb) {
							System.out.println("Not enough Balance");
							break;
						}

						try {
							double transDepositAmount = neftAmount;
							System.out.println("Old Balance of " + neftAccNo + " is "
									+ service2.getAccount(neftAccNo).getbalance());
							service2.depositIntoBalance(neftAccNo, transDepositAmount);
							System.out.println("New Balance of " + neftAccNo + " is "
									+ service2.getAccount(neftAccNo).getbalance());
						} finally {
							System.out.println("Transaction Successful via NEFT.");
							accNoFrom = transFromAcc;
							accNoTo = neftAccNo;
							amount = neftAmount;
							dateOfTrans = new Date();
							transType = "NEFT";
							balance = service2.getAccount(transFromAcc).getbalance();
							transaction = new Transaction(transId, accNoFrom, accNoTo, amount, dateOfTrans, transType,
									balance);
							transId++;
							service3.addTransactionNEFT(transFromAcc, neftAccNo, transaction);
							System.out.println(service2.getAccount(transFromAcc));
						}

						break;

					case 2:
						System.out.println("RTGS selected...");
						System.out.println("Enter beneficiary account number: ");
						long rtgsAccNo = scanner.nextLong();
						try {
							service2.getAccount(rtgsAccNo);
						} catch (AccountNotFound anf) {
							System.out.println("Wrong Account Number of beneficiary... Transaction Cancelled...");
						}
						System.out.println("Enter Amount to transfer: ");
						double rtgsAmount = scanner.nextDouble();

						try {
							double transWithdrawAmount = rtgsAmount;
							if (transWithdrawAmount <= (service2.getAccount(transFromAcc).getbalance())) {
								System.out.println("Old Balance of " + transFromAcc + " is "
										+ service2.getAccount(transFromAcc).getbalance());
								service2.withdrawFromBalance(transFromAcc, transWithdrawAmount);
								System.out.println("New Balance of " + transFromAcc + " is "
										+ service2.getAccount(transFromAcc).getbalance());
							} else {
								throw new NotEnoughBalance("Not enough Balance");
							}
						} catch (NotEnoughBalance neb) {
							System.out.println("Not enough Balance");
							break;
						}

						try {
							double transDepositAmount = rtgsAmount;
							System.out.println("Old Balance of " + rtgsAccNo + " is "
									+ service2.getAccount(rtgsAccNo).getbalance());
							service2.depositIntoBalance(rtgsAccNo, transDepositAmount);
							System.out.println("New Balance of " + rtgsAccNo + " is "
									+ service2.getAccount(rtgsAccNo).getbalance());
						} finally {
							System.out.println("Transaction Successful via RTGS.");
							accNoFrom = transFromAcc;
							accNoTo = rtgsAccNo;
							amount = rtgsAmount;
							dateOfTrans = new Date();
							transType = "RTGS";
							balance = service2.getAccount(transFromAcc).getbalance();
							transaction = new Transaction(transId, accNoFrom, accNoTo, amount, dateOfTrans, transType,
									balance);
							transId++;
							service3.addTransactionNEFT(transFromAcc, rtgsAccNo, transaction);
							System.out.println(service2.getAccount(transFromAcc));
						}
						break;
					case 3:
						System.out.println("IMPS selected...");
						System.out.println("Enter beneficiary account number: ");
						long impsAccNo = scanner.nextLong();
						try {
							service2.getAccount(impsAccNo);
						} catch (AccountNotFound anf) {
							System.out.println("Wrong Account Number of beneficiary... Transaction Cancelled...");
						}
						System.out.println("Enter Amount to transfer: ");
						double impsAmount = scanner.nextDouble();

						try {
							double transWithdrawAmount = impsAmount;
							if (transWithdrawAmount <= (service2.getAccount(transFromAcc).getbalance())) {
								System.out.println("Old Balance of " + transFromAcc + " is "
										+ service2.getAccount(transFromAcc).getbalance());
								service2.withdrawFromBalance(transFromAcc, transWithdrawAmount);
								System.out.println("New Balance of " + transFromAcc + " is "
										+ service2.getAccount(transFromAcc).getbalance());
							} else {
								throw new NotEnoughBalance("Not enough Balance");
							}
						} catch (NotEnoughBalance neb) {
							System.out.println("Not enough Balance");
							break;
						}

						try {
							double transDepositAmount = impsAmount;
							System.out.println("Old Balance of " + impsAccNo + " is "
									+ service2.getAccount(impsAccNo).getbalance());
							service2.depositIntoBalance(impsAccNo, transDepositAmount);
							System.out.println("New Balance of " + impsAccNo + " is "
									+ service2.getAccount(impsAccNo).getbalance());
						} finally {
							System.out.println("Transaction Successful via RTGS.");
							accNoFrom = transFromAcc;
							accNoTo = impsAccNo;
							amount = impsAmount;
							dateOfTrans = new Date();
							transType = "IMPS";
							balance = service2.getAccount(transFromAcc).getbalance();
							transaction = new Transaction(transId, accNoFrom, accNoTo, amount, dateOfTrans, transType,
									balance);
							transId++;
							service3.addTransactionNEFT(transFromAcc, impsAccNo, transaction);
							System.out.println(service2.getAccount(transFromAcc));
						}
						break;
					default:
						System.out.println("Wrong Input... Transaction Cancelled...");
						break;
					}
				} catch (AccountNotFound anf) {
					System.out.println("Enter valid account number...");
				}
				break;

			case 9:

				System.out.println("SHOW ACCOUNT TRANSACTIONS");

				System.out.println("Enter account number to show transactions: ");

				long showTransAccNo = scanner.nextLong();

				try {

					service2.getAccount(showTransAccNo);

					System.out.println(service3.getTransForAccNo(transaction, showTransAccNo));

				} catch (AccountNotFound anf) {

					System.out.println("Enter valid account number....");

				}

				break;

			case 10:// exits from the application
				System.out.println("Thank You !!!!");
				scanner.close();
				System.exit(0);
				break;
			default:
				System.out.println("Wrong Input. Please Try Again!!!");
			}
		}

	}

}
