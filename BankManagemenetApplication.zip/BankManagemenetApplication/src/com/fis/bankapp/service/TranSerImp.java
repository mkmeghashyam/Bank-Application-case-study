package com.fis.bankapp.service;

import java.util.ArrayList;

import com.fis.bankapp.model.Transaction;
import com.fis.bankapp.dao.TransactionRepo;
import com.fis.bankapp.dao.TransactionRepoImplementation;

public class TranSerImp implements TranSer {
	TransactionRepo dao = new TransactionRepoImplementation();

	@Override
	public String addTransactionNEFT(long transFromAcc, long neftAccNo, Transaction transaction) {
		return dao.addTransactionNEFT(transFromAcc, neftAccNo, transaction);
	}

	@Override
	public ArrayList<String> getTransForAccNo(Transaction transaction, long showTransAccNo) {
		return dao.getTransForAccNo(transaction, showTransAccNo);
	}

}
