package com.fis.bankapp.service;

import java.util.ArrayList;

import com.fis.bankapp.model.Transaction;

public interface TranSer {
	public abstract String addTransactionNEFT(long transFromAcc, long neftAccNo, Transaction transaction);
	
	public abstract ArrayList<String> getTransForAccNo(Transaction transaction, long showTransAccNo);
}
