package com.fis.bankapp.service;

import java.util.Set;

import com.fis.bankapp.model.Customer;
import com.fis.bankapp.exceptions.CustomerNotFound;

public interface CusSer {
	public abstract String addCustomer(Customer customer);

	public abstract String updateCustomer(Customer customer) throws CustomerNotFound;

	public abstract String deleteCustomer(int custId) throws CustomerNotFound;

	public abstract Customer getCustomer(int custId) throws CustomerNotFound;

	public abstract Set<Customer> getAllCustomers();

}
