package com.fis.bankapp.service;

import com.fis.bankapp.model.Account;
import com.fis.bankapp.exceptions.AccountNotFound;
import com.fis.bankapp.exceptions.NotEnoughBalance;
import com.fis.bankapp.dao.AccountRepository;
import com.fis.bankapp.dao.AccountRepositoryImplementation;

public class AccSerImp implements AccSer {
	AccountRepository dao = new AccountRepositoryImplementation();

	@Override
	public String addAccount(Account account) {
		return dao.addAccount(account);

	}

	@Override
	public String deleteAccount(long accNo) throws AccountNotFound {

		return dao.deleteAccount(accNo);
	}

	@Override
	public Account getAccount(long getAcc) throws AccountNotFound {
		return dao.getAccount(getAcc);

	}

	@Override
	public void withdrawFromBalance(long getAcc, double withdrawAmount) throws NotEnoughBalance {

		dao.withdrawFromBalance(getAcc, withdrawAmount);
	}

	@Override
	public void depositIntoBalance(long getAcc, double depositAmount) {

		dao.depositIntoBalance(getAcc, depositAmount);
	}


}
