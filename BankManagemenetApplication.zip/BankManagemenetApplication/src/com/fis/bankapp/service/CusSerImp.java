package com.fis.bankapp.service;

import java.util.Set;

import com.fis.bankapp.model.Customer;
import com.fis.bankapp.exceptions.CustomerNotFound;
import com.fis.bankapp.dao.CustomerRepository;
import com.fis.bankapp.dao.CustomerRepositoryImplementation;

public class CusSerImp implements CusSer {

	CustomerRepository dao = new CustomerRepositoryImplementation();

	@Override
	public String addCustomer(Customer customer) {
		return dao.addCustomer(customer);
	}

	@Override
	public String updateCustomer(Customer customer) throws CustomerNotFound {

		return dao.updateCustomer(customer);
	}

	@Override
	public String deleteCustomer(int custId) throws CustomerNotFound {

		return dao.deleteCustomer(custId);
	}

	@Override
	public Customer getCustomer(int custId) throws CustomerNotFound {

		return dao.getCustomer(custId);
	}

	@Override
	public Set<Customer> getAllCustomers() {

		return dao.getAllCustomers();
	}

}
