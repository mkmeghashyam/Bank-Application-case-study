package com.fis.bankapp.exceptions;

public class CustomerNotFound extends Exception {//extending from exception 

	public CustomerNotFound(String message) {
		super(message);
	}

}
