package com.fis.bankapp.exceptions;

public class TransactionNotFound extends Exception {// extending from exception class

	public TransactionNotFound(String message) {
		super(message);
	}

}
