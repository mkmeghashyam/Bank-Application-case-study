package com.fis.bankapp.exceptions;

public class AccountNotFound extends Exception {//extending from exception class

	public AccountNotFound(String message) {
		super(message);
	}

}
