package com.fis.bankapp.exceptions;

public class NotEnoughBalance extends Exception { //extending from exception class
	public NotEnoughBalance(String message) {
		super(message);
	}
}
